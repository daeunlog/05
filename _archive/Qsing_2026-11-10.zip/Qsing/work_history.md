# 큐싱 탐지 앱 — 작업 기록

> 페이즈별 작업 내용을 기록한다. 새 내용은 항상 아래에 추가하며 기존 내용은 수정·삭제하지 않는다.

---

## 2026-11-09 · 설계 단계

### 결정 사항
- 범위: AI 모델 파트부터 진행 (데이터·URLBERT·평가·서버용 추론 모듈)
- 학습 환경: Kaggle Notebook (GPU)
- 접근법: B안 — 기본 인코더 위에 4종 헤드를 직접 학습, 제공 `malicious_urls_4class` 헤드는 기준선
  - 이유: 모델 카드상 제공 헤드가 Malicious URLs Dataset·PhiUSIIL로 학습되어, 이 데이터로 평가하면 성능이 부풀려짐
- 필수 평가 지표 7종 고정: Accuracy, 클래스별 Precision·Recall·F1, Macro F1, 혼동행렬, 정상 URL 오탐률, 악성 URL 미탐률

### 페이즈 계획
P0 환경 준비 → P1 데이터 점검·전처리 → P2 그룹 분리 → P3 기준선 → P4 헤드 학습 → P5 평가 → P6 위험도 임계값 → P7 서버용 추론 모듈

### 산출물
- `docs/specs/2026-11-09-urlbert-model-design.md` (설계 문서)
- `work_history.md` (이 파일)

### 메모
- 로컬 작업 환경: GPU·인터넷·PyTorch 없음 → 학습은 Kaggle에서 사용자가 실행
- Qsing 폴더는 git 저장소가 아님 (커밋 생략)
- 로컬 패키지 확인: pandas·numpy·matplotlib 있음 / pytest·scikit-learn·tldextract 없음 → 이 셋에 의존하는 테스트는 Kaggle 첫 셀에서 실행, 나머지는 표준 라이브러리(unittest)로 로컬 실행

---

## 2026-11-09 · 설계 개정 1 — 외부 최신 데이터 평가 추가

### 결정 사항
- 학습 데이터는 Malicious URLs 유지. 추가 데이터는 **평가 전용**으로만 사용
  - 이유: 클래스마다 출처가 하나씩이면 모델이 위험 여부 대신 출처의 URL 모양을 학습할 위험
- 평가 출처: URLhaus(malware), OpenPhish Community Feed(phishing), Tranco(benign), PhishTank(phishing, 선택)
- defacement는 공개 출처가 없어 외부 평가에서 제외
- 외부 세트에서는 Precision·Macro F1을 내지 않고 출처별 미탐률·오탐률·유형 일치율과 95% 신뢰구간 보고

### 확인한 출처 현황 (2026-11-09)
- URLhaus: 무료 abuse.ch Auth-Key 필요, 공정 이용 원칙, 상업적 이용은 유료
- OpenPhish Community Feed: 12시간마다 갱신, 비상업적 이용만 허용
- PhishTank: 신규 회원가입이 막혀 있음, 키 없이 하루 몇 번만 다운로드 가능
- Tranco: 연구용 Top 1M 목록, 고정 list ID로 재현 가능

### 변경 파일
- `docs/specs/2026-11-09-urlbert-model-design.md` — 하단에 "개정 1" 섹션 추가 (기존 내용 수정 없음)
- 교수님 설명 문서 작성 예정
- 교수님 설명 문서 작성 완료 (Claude Docs): https://claude.ai/artifact/W3XoLpTXhhmLtwitcFzN6t
  - 내용: 데이터셋별 역할, 제공 헤드 대신 직접 학습하는 이유, 추가 데이터를 학습에 섞지 않는 이유, 분리 규칙, 필수 지표 7종, 외부 최신 데이터 평가, 위험도 산출, 한계, 일정
  - 일정 가정: 11/24 서버 담당에게 모델 전달 (팀 확인 필요)

---

## 2026-11-10 · 구현 — P0~P7 코드와 Kaggle 노트북

### 페이즈별 작업
| 페이즈 | 구현 | 위치 |
|---|---|---|
| 기반 | 4종 라벨 순서, URL 파싱(scheme 판별·호스트·등록 도메인·정규화·보조 신호) | `model/qsing_model/labels.py`, `urls.py` |
| P0 | 환경 확인, 저장소 커밋 해시 고정, 제공 헤드 원격 코드 출력 | `pipeline.p0_environment`, `baseline.py` |
| P1 | 데이터 로더(Malicious URLs, PhiUSIIL, URLhaus, OpenPhish, PhishTank, Tranco), 정제, scheme 분포 점검, 외부 평가 세트 구성 | `data.py`, `pipeline.p1_prepare` |
| P2 | StratifiedGroupKFold 20폴드 → 14/3/3, 도메인 교집합·비율(±2%p) 검사 | `split.py`, `pipeline.p2_split` |
| P3 | 제공 헤드 기준선 평가 (라벨 자동 매핑, max_length 보정) | `baseline.py`, `pipeline.p3_baseline` |
| P4 | CLS+MEAN 임베딩(FP16, 길이순 배치, 잘림 표시), Linear/MLP 헤드 학습(AdamW, balanced 가중치, 조기 종료) | `embed.py`, `head.py`, `train.py`, `pipeline.p4_*` |
| P6 | val 기준 임계값 (정상 1% 이하 위험, 악성 99% 이상 주의 이상) | `risk.py`, `pipeline.p6_thresholds` |
| P5 | 필수 지표 7종(누락 시 예외), PhiUSIIL 이진 평가·AUROC, 외부 출처별 지표·Wilson 95% CI, 기준선 비교, 혼동행렬 그림, scheme 변형 test | `metrics.py`, `pipeline.p5_evaluate` |
| P7 | 서버용 `UrlRiskClassifier`, artifacts 내보내기(인코더 포함), 학습-서버 일치율, CPU 추론 시간 | `infer.py`, `pipeline.p7_export` |
| 노트북 | 코드 복사·패키지 확인 → 단위 테스트 → 입력 자동 탐색 → P0 → 리허설(6천 건) → 본 실행 → 요약 | `model/notebooks/qsing_kaggle.ipynb` |

### 테스트 (로컬, torch 없음)
- `python -m pytest model/tests` → 37 통과, 1 건너뜀(torch와 numpy 헤드 비교 — Kaggle에서 실행)
- 파이프라인 리허설: 가짜 임베더·가짜 학습기로 P1→P2→P4→P6→P5→P7 전체 흐름과 산출물 형식 확인

### 구현 중 발견해 바꾼 것 (설계 개정 2 → `docs/specs/2026-11-10-urlbert-model-design-개정2.md`)
1. **임계값 판단 정정**: `t_low ≥ t_high`는 "목표 동시 충족 불가"가 아니라 "두 목표가 이미 함께 충족(잘 갈림)"이다. 이 경우 '주의' 구간을 비우고 `status=separated`로 보고
2. **모델 선택 기준 보강**: val Macro F1 → val Macro F1의 **최저값**(원본 / scheme 제거 / https 추가). 리허설에서 raw 모델이 scheme 지름길을 학습해 원본 val 1.00, 변형 val 0.57이 나옴
3. 실행 순서 P6 → P5 (임계값 기준 오탐·미탐률에 P6 결과 필요, P6은 val만 사용)
4. 헤드 저장을 `head.npz`로 (pickle 미사용), 서버 헤드 계산은 numpy
5. 리허설 단계, 학습-서버 일치율, artifacts 기반 CPU 추론 시간 측정 추가

### 문서
- `docs/model_api.md` — 서버 연동 안내 (FastAPI 예시, 반환 형식, 상태별 처리)
- `model/README.md` — 집/Kaggle에서 실행하는 순서, 막힐 때 조치
- 교수님 설명 문서(Claude Docs) 정정 2곳(임계값 판단, 모델 선택 기준) → `docs/URLBERT_큐싱탐지모델_데이터셋평가계획.pdf` 다시 내보냄

### 다음 할 일
- [ ] Kaggle에 `qsing-code`, PhiUSIIL, (선택) 외부 데이터 업로드 후 노트북 Run All
- [ ] 노트북 마지막 셀의 실행 결과 요약을 이 파일 아래에 붙여넣기
- [ ] `qsing_artifacts.zip`을 `model/artifacts/`에 풀고 김다은 님께 전달 (11/24 목표, 팀 확인 필요)
