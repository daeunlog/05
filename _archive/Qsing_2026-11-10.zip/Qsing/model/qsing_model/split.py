"""도메인 그룹 단위 70:15:15 분리와 누수 검사 (설계 2.4절)."""

import numpy as np
import pandas as pd

N_SPLITS = 20
TEST_FOLDS = (0, 1, 2)
VAL_FOLDS = (3, 4, 5)
RATIO_TOLERANCE_PP = 2.0


class SplitCheckError(RuntimeError):
    pass


def group_split(df, seed=42, n_splits=N_SPLITS):
    """StratifiedGroupKFold로 폴드를 만들고 train 14 / val 3 / test 3 폴드로 묶는다.

    반환: df 사본에 'split' 컬럼(train/val/test) 추가
    """
    from sklearn.model_selection import StratifiedGroupKFold

    d = df.reset_index(drop=True).copy()
    fold = np.full(len(d), -1, dtype=int)
    sgkf = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    for k, (_, idx) in enumerate(sgkf.split(np.zeros(len(d)), d["label"].values, d["group_key"].values)):
        fold[idx] = k
    if (fold < 0).any():
        raise SplitCheckError("폴드가 배정되지 않은 행이 있습니다.")
    d["split"] = np.where(np.isin(fold, TEST_FOLDS), "test",
                          np.where(np.isin(fold, VAL_FOLDS), "val", "train"))
    return d


def check_split(d, tolerance_pp=RATIO_TOLERANCE_PP, top_n=20):
    """누수·비율 검사. 실패하면 SplitCheckError. 반환: 리포트 dict"""
    rep = {}
    groups = {s: set(d.loc[d["split"] == s, "group_key"]) for s in ("train", "val", "test")}
    overlaps = {
        "train&val": len(groups["train"] & groups["val"]),
        "train&test": len(groups["train"] & groups["test"]),
        "val&test": len(groups["val"] & groups["test"]),
    }
    rep["group_overlaps"] = overlaps

    overall = d["label"].value_counts(normalize=True) * 100
    ratios = {}
    worst = 0.0
    for s in ("train", "val", "test"):
        part = d.loc[d["split"] == s, "label"].value_counts(normalize=True) * 100
        part = part.reindex(overall.index, fill_value=0.0)
        diff = (part - overall).abs()
        worst = max(worst, float(diff.max()))
        ratios[s] = {k: round(float(v), 2) for k, v in part.items()}
    rep["overall_pct"] = {k: round(float(v), 2) for k, v in overall.items()}
    rep["split_pct"] = ratios
    rep["max_ratio_diff_pp"] = round(worst, 3)
    rep["sizes"] = {s: int((d["split"] == s).sum()) for s in ("train", "val", "test")}
    rep["size_pct"] = {s: round(100 * n / len(d), 2) for s, n in rep["sizes"].items()}
    top = d.groupby("group_key").size().sort_values(ascending=False).head(top_n)
    rep["top_groups"] = [{"group_key": g, "rows": int(n), "split": d.loc[d["group_key"] == g, "split"].iloc[0]}
                         for g, n in top.items()]

    errors = []
    if any(v > 0 for v in overlaps.values()):
        errors.append(f"세트 간 그룹 교집합이 있습니다: {overlaps}")
    if worst > tolerance_pp:
        errors.append(f"클래스 비율 차이 {worst:.2f}%p가 허용치 {tolerance_pp}%p를 넘습니다.")
    rep["passed"] = not errors
    if errors:
        raise SplitCheckError(" / ".join(errors) + f"\n리포트: {rep}")
    return rep
